    function OP0= get_op0(mu,sig,c,T,T2,dt, y)    
        
    % zero coupou bond
    N= round(T/dt)+1;
    ZCP= zeros(N+1); 
        
    for n= 1:N+1
        ZCP(n) = (1+ y*dt)^(-n);
    end
    
    % rate tree
    r(1,1)=y;
    
    for j=2:N
        r(1,j)= r(1,j-1)+mu*dt-sig*sqrt(dt);
        for i=2:j
            r(i,j)= r(i-1,j-1)+mu*dt+sig*sqrt(dt);
        end
    end
    
    % q and bond tree
    q= zeros(N-1);
    P= zeros(N,N);
    P1=P; P2=P;
    q(1)= (mu-r(1,1))*sqrt(dt)/2*sig + 0.5;
    
    for n=3:N
        for i=1:n
            P(i,n)= 1/(1+r(i,n)*dt);
        end
        for i=1:n-1
            P1(i,n-1)= P(i+1,n)/(1+r(i,n)*dt);
            P2(i,n-1)= ( P(i,n)-P(i+1,n) )/(1+r(i,n)*dt);
        end
        for j=n-2:-1:1
            for i=1:j
                DC = (1+r(i,j)*dt);
                P1(i,j)= (q(j)*P1(i,j+1)+(1-q(j))*P1(i+1,j+1))/DC;
                P2(i,j)= (q(j)*P2(i,j+1)+(1-q(j))*P2(i+1,j+1))/DC;
            end
        end
        q(n-1)= (ZCP(n+1)- P1(1,1))/P2(1,1);
    end
    
    % bond and option tree
    B= zeros(N,N);
    N2 = round(T2/dt)+1;
    K = ZCP(N-N2);
    C= zeros(N2,N2);
    for i=1:N 
        B(i,N) = 1;
    end
    for j= N-1:-1:1
        for i= 1:j
            DC = 1+r(i,j)*dt;
            B(i,j)= (q(j)*B(i,j+1)+(1-q(j))*B(i+1,j+1)+c/2)/DC;
        end
    end
    
    for i=1:N2
        C(i,N2)= max(B(i,N2)-K, 0);
    end
    for j=N2-1:-1:1
        for i= 1:j
            DC = 1+r(i,j)*dt;
            C(i,j)= (q(j)*C(i,j+1)+(1-q(j))*C(i+1,j+1))/DC;
        end
    end
    
    OP0= C(1,1);
    return