%   HW8 Q2

    DCF=0.98; sig=0.25;
    S0=150; T=1/4;
    dK=5;
    K=100:dK:200; CP=zeros(size(K));
    F=S0/DCF;
    for i=1:length(K)
        Ki=K(i);
        CP(i)=call(F,Ki,T,sig);
    end
    plot(K,CP);