
%   Specify the term structure of quarlerly forward rates

    df=(0.0250-0.002)/120; 
    f=0.002:df:(0.002+120*df);
    
%   Calculate the discount curve

    dT=0.5; dTh=dT/2;
    T=10;                       % swap maturity
    Not=1000000;                % notional value of the swap
    N=T/dT;
    P=zeros(N,1);
    P(1)=1/((1+dTh*f(1))*(1+dTh*f(2)));
    for j=2:N
        P(j)=P(j-1)/((1+dTh*f(2*j-1))*(1+dTh*f(2*j)));
    end

%   Calculate the initial swap rate

    ann=0.0;
    for j=1:N
        ann=ann+dT*P(j);
    end
    sr0=(1-P(N))/ann;

%   Specify forward rate curve at t

    t=5;
    df=0.03/120; 
    f=0.0026:df:(0.0026+120*df);
    
%   Calculate discount curve at t

    T=(T-t); N=T/dT;
    P=zeros(N,1);
    P(1)=1/((1+dTh*f(1))*(1+dTh*f(2)));
    for j=2:N
        P(j)=P(j-1)/((1+dTh*f(2*j-1))*(1+dTh*f(2*j)));
    end

%   Calculate swap rate at a later time t

    ann=0.0;
    for j=1:N
        ann=ann+dT*P(j);
    end
    sr1=(1-P(N))/ann;
    
%   Calculate the MtM value of the swap

    MtM=Not*(sr1-sr0)*ann