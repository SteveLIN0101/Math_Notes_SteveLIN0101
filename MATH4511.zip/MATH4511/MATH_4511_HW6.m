
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   MATH 4511 Homework 6                                                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Input parameter

    mu=0.005; sig=0.0075;
    c=0.03; T=10; T2=5;
   
    dt = [0.5, 0.25];
    y0= [0.0295, 0.02939];
    y1 = 0.005:0.005:0.06;
    
% 1.1
    fprintf('1.1 result: %f\n', 100*get_op0(mu,sig,c,T,T2,dt(1),y0(1)));
    
% 1.2
    OP = zeros(length(y1));
    for i=1:length(y1)
        OP(i)= 100*get_op0(mu,sig,c,T,T2,dt(1),y1(i));
    end
    plot(y1,OP,'rd');
 
% 1.3
    fprintf('1.3 result: %f\n', 100*get_op0(mu,sig,c,T,T2,dt(2),y0(2)));
    OP = zeros(length(y1));
    for i=1:length(y1)
       OP(i)= 100*get_op0(mu,sig,c,T,T2,dt(2),y1(i));
    end
    plot(y1,OP,'rd');